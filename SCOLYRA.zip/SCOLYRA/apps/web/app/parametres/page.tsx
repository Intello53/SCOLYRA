export default function ParametresPage() {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="mb-2 text-2xl font-bold">Paramètres</h1>
      <p className="text-sm text-neutral-500">
        Squelette d interface — page non encore connectée à la base de
        données réelle (voir docs/STATUS.md pour l état d avancement).
      </p>
    </div>
  );
}
