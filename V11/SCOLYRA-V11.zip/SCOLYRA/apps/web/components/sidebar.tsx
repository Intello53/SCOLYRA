"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { signOut } from "next-auth/react";
import { ProgressRing } from "./progress-ring";

export const NAV_GROUPS = [
  {
    label: "Travail",
    links: [
      { href: "/dashboard", label: "Tableau de bord" },
      { href: "/objectifs", label: "Objectifs" },
      { href: "/revisions", label: "Révisions" },
      { href: "/calendrier", label: "Calendrier" },
      { href: "/coach", label: "Coach IA" },
    ],
  },
  {
    label: "Suivi",
    links: [
      { href: "/matieres", label: "Matières" },
      { href: "/documents", label: "Documents" },
      { href: "/projets", label: "Projets" },
      { href: "/orientation", label: "Orientation" },
    ],
  },
  {
    label: "Compte",
    links: [
      { href: "/profil", label: "Profil" },
      { href: "/parametres", label: "Paramètres" },
      { href: "/aide", label: "Aide & assistance" },
    ],
  },
];

export function Sidebar({
  firstName,
  overallAverage,
  overallTarget,
  activeDaysThisWeek,
}: {
  firstName: string;
  overallAverage: number;
  overallTarget: number;
  activeDaysThisWeek: number;
}) {
  const pathname = usePathname();

  return (
    <aside className="hidden w-72 flex-col bg-ink-900 p-5 md:flex">
      <Link href="/" className="mb-6 flex items-center gap-2 px-1">
        <span className="font-display text-xl text-white">Scolyra</span>
      </Link>

      <div className="mb-4 rounded-xl bg-white/5 p-4">
        <ProgressRing current={overallAverage} target={overallTarget} label={`${firstName} · moyenne générale`} />
      </div>

      <div className="mb-6 flex items-center gap-2 rounded-xl bg-gradient-to-r from-gold-500/15 to-transparent px-3 py-2">
        <motion.span
          className="text-lg"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
        >
          🔥
        </motion.span>
        <span className="text-sm text-gold-200">
          <strong className="font-display">{activeDaysThisWeek}</strong>/7 jours actifs cette semaine
        </span>
      </div>

      <nav className="flex flex-1 flex-col gap-5 overflow-y-auto">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="mb-1.5 px-3 text-xs font-medium uppercase tracking-wider text-white/55">
              {group.label}
            </p>
            <div className="flex flex-col gap-0.5">
              {group.links.map((link) => {
                const active = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`focus-ring relative rounded-lg px-3 py-2 text-sm transition-colors ${
                      active ? "text-white" : "text-white/60 hover:text-white"
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="sidebar-active-pill"
                        className="absolute inset-0 rounded-lg bg-white/10"
                        transition={{ type: "spring", stiffness: 500, damping: 35 }}
                      />
                    )}
                    <span className="relative">{link.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-4 px-1">
        <Link href="/docs" className="text-xs text-white/55 hover:text-white/70">
          Documentation
        </Link>
        <button onClick={() => signOut({ callbackUrl: "/" })} className="focus-ring text-xs text-white/55 hover:text-white/70">
          Déconnexion
        </button>
      </div>
    </aside>
  );
}
